const AURORA_PRODUCTS = [
  {
    sku: "ABS-BH-001",
    name: "Premium Turn Lock for Handbags",
    category: "Bag Hardware",
    material: "Zinc Alloy",
    color: "Light Gold / Nickel / Gunmetal",
    finish: "Electroplated",
    size: "32 x 25 mm",
    price: "Request Quote",
    moq: "300 pcs",
    image: "assets/images/bag-hardware.jpg",
    tags: ["Featured", "Best Seller"],
    application: "Handbags, shoulder bags, leather cases",
  },
  {
    sku: "ABS-LH-002",
    name: "Heavy Duty Luggage Hook",
    category: "Luggage Hardware",
    material: "Zinc Alloy",
    color: "Black Nickel / Antique Brass",
    finish: "Plated and sealed",
    size: "45 mm",
    price: "Request Quote",
    moq: "500 pcs",
    image: "assets/images/hooks.jpg",
    tags: ["Featured"],
    application: "Travel bags, outdoor bags, luggage straps",
  },
  {
    sku: "ABS-BT-003",
    name: "Solid Belt Buckle",
    category: "Belt Hardware",
    material: "Brass / Zinc Alloy",
    color: "Brass / Silver / Matte Black",
    finish: "Polished or brushed",
    size: "35 mm inner width",
    price: "$1.20 - $2.80",
    moq: "200 pcs",
    image: "assets/images/custom-hardware.jpg",
    tags: ["Best Seller"],
    application: "Leather belts, fashion belts, uniform belts",
  },
  {
    sku: "ABS-LM-004",
    name: "Full Grain Leather Panel",
    category: "Leather Materials",
    material: "Genuine Leather",
    color: "Brown / Black / Custom Color",
    finish: "Natural grain",
    size: "1.2 - 1.6 mm thickness",
    price: "Request Quote",
    moq: "50 sq ft",
    image: "assets/images/leather-materials.jpg",
    tags: ["New Arrival"],
    application: "Bags, belts, small leather goods",
  },
  {
    sku: "ABS-MF-005",
    name: "Microfiber Leather Roll",
    category: "Microfiber Leather",
    material: "Microfiber PU",
    color: "Black / Cream / Custom",
    finish: "Smooth or pebbled",
    size: "1.0 - 1.4 mm thickness",
    price: "$5.80 - $9.50 / yard",
    moq: "100 yards",
    image: "assets/images/quality.jpg",
    tags: ["New Arrival"],
    application: "Production bags, lining, straps",
  },
  {
    sku: "ABS-ZP-006",
    name: "Metal Zipper and Puller Set",
    category: "Zippers & Pullers",
    material: "Brass / Aluminum / Zinc Puller",
    color: "Gold / Nickel / Antique Brass",
    finish: "Metal teeth with plated puller",
    size: "#3 / #5 / #8",
    price: "$0.45 - $1.60",
    moq: "1000 sets",
    image: "assets/images/zippers.jpg",
    tags: ["Featured", "New Arrival"],
    application: "Handbags, luggage, wallets, backpacks",
  },
  {
    sku: "ABS-RS-007",
    name: "Rivets, Snaps and Eyelets Kit",
    category: "Rivets, Snaps & Eyelets",
    material: "Brass / Iron / Stainless Steel",
    color: "Gold / Silver / Gunmetal",
    finish: "Plated",
    size: "4 - 12 mm",
    price: "$0.01 - $0.08",
    moq: "5000 pcs",
    image: "assets/images/rivets.jpg",
    tags: ["Best Seller"],
    application: "Leather goods, bag panels, straps",
  },
  {
    sku: "ABS-CH-008",
    name: "Custom Logo Metal Plate",
    category: "Custom Hardware",
    material: "Zinc Alloy / Brass / Stainless Steel",
    color: "Custom Plating",
    finish: "Engraved, embossed, enamel or brushed",
    size: "Custom mold",
    price: "Request Quote",
    moq: "500 pcs",
    image: "assets/images/custom-hardware.jpg",
    tags: ["Featured"],
    application: "Brand bags, leather goods, packaging",
  },
];

const CATEGORIES = [
  ["Bag Hardware", "High-quality buckles, hooks, rings, locks and decorative hardware for handbags.", "assets/images/bag-hardware.jpg"],
  ["Luggage Hardware", "Durable components for luggage, travel bags and outdoor bags.", "assets/images/hooks.jpg"],
  ["Belt Hardware", "Belt buckles, loops, tips and accessories for leather belts.", "assets/images/custom-hardware.jpg"],
  ["Leather Materials", "Genuine leather and leather panels for bags, belts and accessories.", "assets/images/leather-materials.jpg"],
  ["Microfiber Leather", "Durable and consistent synthetic leather materials for production.", "assets/images/quality.jpg"],
  ["Zippers & Pullers", "Metal zippers, nylon zippers, zipper sliders and pullers.", "assets/images/zippers.jpg"],
  ["Rivets, Snaps & Eyelets", "Small metal parts for leather goods and bag production.", "assets/images/rivets.jpg"],
  ["Custom Hardware", "Custom logo, shape, plating and material options for your brand.", "assets/images/custom-hardware.jpg"],
];

function productCard(product) {
  const badge = product.tags[0] ? `<span class="badge">${product.tags[0]}</span>` : "";
  return `
    <article class="product-card">
      <a class="product-card__image" href="product-detail.html?sku=${encodeURIComponent(product.sku)}">
        ${badge}
        <img src="${product.image}" alt="${product.name}" />
      </a>
      <div class="product-card__body">
        <h3>${product.name}</h3>
        <div class="product-specs">
          <span><strong>Material:</strong> ${product.material}</span>
          <span><strong>Color:</strong> ${product.color}</span>
          <span><strong>Size:</strong> ${product.size}</span>
          <span><strong>MOQ:</strong> ${product.moq}</span>
        </div>
        <div class="price-line">${product.price}</div>
        <div class="product-actions">
          <a class="btn" href="product-detail.html?sku=${encodeURIComponent(product.sku)}">View Details</a>
          <a class="btn btn-primary" href="contact.html?sku=${encodeURIComponent(product.sku)}">Add / Quote</a>
        </div>
      </div>
    </article>
  `;
}

function renderCategories() {
  const target = document.querySelector("[data-category-grid]");
  if (!target) return;
  target.innerHTML = CATEGORIES.map(([name, text, image]) => `
    <a class="category-card" href="products.html?category=${encodeURIComponent(name)}">
      <img src="${image}" alt="${name}" />
      <h3>${name}</h3>
      <p>${text}</p>
    </a>
  `).join("");
}

function renderProductGrids() {
  document.querySelectorAll("[data-products]").forEach((target) => {
    const mode = target.dataset.products;
    let products = AURORA_PRODUCTS;
    if (mode === "featured") products = products.filter((item) => item.tags.includes("Featured"));
    if (mode === "new") products = products.filter((item) => item.tags.includes("New Arrival"));
    if (mode === "best") products = products.filter((item) => item.tags.includes("Best Seller"));
    target.innerHTML = products.slice(0, 8).map(productCard).join("");
  });
}

function renderCatalog() {
  const grid = document.querySelector("[data-catalog-grid]");
  if (!grid) return;
  const params = new URLSearchParams(window.location.search);
  const category = params.get("category");
  const query = (params.get("q") || "").toLowerCase();
  let products = AURORA_PRODUCTS;
  if (category) products = products.filter((item) => item.category === category);
  if (query) {
    products = products.filter((item) =>
      [item.name, item.category, item.material, item.color, item.finish, item.application].join(" ").toLowerCase().includes(query)
    );
  }
  document.querySelector("[data-catalog-count]").textContent = `${products.length} products`;
  grid.innerHTML = products.map(productCard).join("");
}

function renderDetail() {
  const detail = document.querySelector("[data-product-detail]");
  if (!detail) return;
  const params = new URLSearchParams(window.location.search);
  const product = AURORA_PRODUCTS.find((item) => item.sku === params.get("sku")) || AURORA_PRODUCTS[0];
  document.title = `${product.name} | Aurora Bag Supply`;
  const thumbs = [product.image, "assets/images/quality.jpg", "assets/images/factory.jpg", "assets/images/leather-materials.jpg"];
  detail.innerHTML = `
    <div class="product-detail">
      <div>
        <div class="gallery-main"><img src="${product.image}" alt="${product.name}" /></div>
        <div class="gallery-thumbs">${thumbs.map((image) => `<div class="gallery-thumb"><img src="${image}" alt="${product.name}" /></div>`).join("")}</div>
      </div>
      <aside class="detail-panel">
        <p class="kicker">${product.category}</p>
        <h1>${product.name}</h1>
        <p class="sku">SKU: ${product.sku}</p>
        <dl class="detail-specs">
          <dt>Material</dt><dd>${product.material}</dd>
          <dt>Color / Finish</dt><dd>${product.color} / ${product.finish}</dd>
          <dt>Size</dt><dd>${product.size}</dd>
          <dt>Application</dt><dd>${product.application}</dd>
          <dt>Stock Status</dt><dd>Available for production</dd>
          <dt>MOQ</dt><dd>${product.moq}</dd>
          <dt>Price</dt><dd>${product.price}</dd>
        </dl>
        <div class="qty-row"><label for="qty">Quantity</label><input id="qty" type="number" min="1" value="300" /></div>
        <div class="hero-actions">
          <a class="btn btn-primary" href="contact.html?sku=${encodeURIComponent(product.sku)}">Add to Cart</a>
          <a class="btn btn-brass" href="contact.html?sku=${encodeURIComponent(product.sku)}">Request a Quote</a>
          <a class="btn" href="account.html">Add to Wishlist</a>
        </div>
      </aside>
    </div>
    <div class="tab-box">
      <div class="tabs" data-tabs>
        <button class="is-active" data-tab="description">Product Description</button>
        <button data-tab="specifications">Specifications</button>
        <button data-tab="customization">Customization</button>
        <button data-tab="shipping">Shipping & Delivery</button>
        <button data-tab="faq">FAQ</button>
      </div>
      <div class="tab-panel is-active" data-panel="description">
        <p>${product.name} is designed for B2B bag production and custom leather goods projects. It supports stable reorder quality, export packing and custom finish requirements.</p>
      </div>
      <div class="tab-panel" data-panel="specifications">
        <table class="spec-table">
          <tbody>
            <tr><th>Material</th><td>${product.material}</td></tr>
            <tr><th>Size</th><td>${product.size}</td></tr>
            <tr><th>Color</th><td>${product.color}</td></tr>
            <tr><th>Finish</th><td>${product.finish}</td></tr>
            <tr><th>Weight</th><td>Depends on size and material</td></tr>
            <tr><th>MOQ</th><td>${product.moq}</td></tr>
            <tr><th>Application</th><td>${product.application}</td></tr>
            <tr><th>Custom Logo</th><td>Available</td></tr>
            <tr><th>Packaging</th><td>OPP bag, inner box, export carton, custom label</td></tr>
          </tbody>
        </table>
      </div>
      <div class="tab-panel" data-panel="customization">
        <ul class="check-list"><li>Logo engraving</li><li>Color plating</li><li>Size adjustment</li><li>Material selection</li><li>Custom mold development</li></ul>
      </div>
      <div class="tab-panel" data-panel="shipping">
        <p>Samples can be shipped by express. Bulk orders can be packed by carton and shipped by air, sea or forwarder warehouse according to your destination market.</p>
      </div>
      <div class="tab-panel" data-panel="faq">
        <p><strong>Can I request wholesale pricing?</strong> Yes. Register an account or submit the quote form with quantity and target market.</p>
        <p><strong>Can I customize finish and logo?</strong> Yes. Please send drawings, finish reference and expected quantity.</p>
      </div>
    </div>
  `;
}

function bindTabs() {
  document.addEventListener("click", (event) => {
    const button = event.target.closest("[data-tab]");
    if (!button) return;
    const box = button.closest(".tab-box");
    box.querySelectorAll("[data-tab]").forEach((item) => item.classList.toggle("is-active", item === button));
    box.querySelectorAll("[data-panel]").forEach((panel) => panel.classList.toggle("is-active", panel.dataset.panel === button.dataset.tab));
  });
}

function bindForms() {
  document.querySelectorAll("[data-demo-form]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const message = form.dataset.success || "Thank you. Our sales team will contact you within 24 hours.";
      alert(message);
    });
  });
  const menu = document.querySelector("[data-mobile-menu]");
  const nav = document.querySelector(".category-nav");
  if (menu && nav) menu.addEventListener("click", () => nav.classList.toggle("is-open"));
}

renderCategories();
renderProductGrids();
renderCatalog();
renderDetail();
bindTabs();
bindForms();
