<?php get_header(); ?>
<main>
  <section class="hero">
    <div class="container hero-slider">
      <div class="hero-copy">
        <p class="kicker">Factory supply | Custom hardware | Leather materials</p>
        <h1>Premium Bag Hardware & Leather Materials Supplier</h1>
        <p>Reliable components for handbags, luggage, belts, leather goods and custom bag manufacturing.</p>
        <div class="hero-actions">
          <a class="btn btn-primary" href="<?php echo esc_url(function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/')); ?>">Shop Products</a>
          <a class="btn btn-brass" href="<?php echo esc_url(home_url('/contact/')); ?>">Request a Quote</a>
          <a class="btn" href="<?php echo esc_url(home_url('/custom-solutions/')); ?>">Custom Hardware Service</a>
        </div>
      </div>
      <div class="hero-media"></div>
      <div class="hero-dots"><span></span><span></span><span></span><span></span><span></span></div>
    </div>
  </section>
  <section class="trust-row">
    <div class="trust-item"><strong>Factory Supply</strong><span>Stable production and export packing</span></div>
    <div class="trust-item"><strong>Customizable Hardware</strong><span>Logo, plating, size and mold options</span></div>
    <div class="trust-item"><strong>Worldwide Shipping</strong><span>Support for importers and online brands</span></div>
  </section>
  <section class="section">
    <div class="container">
      <div class="section-head"><h2>Shop by Category</h2><p>Quickly find the hardware, leather material and accessory category you need.</p></div>
      <?php echo do_shortcode('[product_categories number="8" columns="4" hide_empty="0"]'); ?>
    </div>
  </section>
  <section class="section section-alt">
    <div class="container">
      <div class="section-head"><h2>Featured Products</h2><p>Core product systems for bag factories, leather workshops and sourcing teams.</p></div>
      <?php echo do_shortcode('[products limit="8" columns="4" visibility="featured"]'); ?>
    </div>
  </section>
  <section class="section">
    <div class="container">
      <div class="section-head"><h2>New Arrivals</h2><p>Recently prepared materials and components for production buyers.</p></div>
      <?php echo do_shortcode('[products limit="8" columns="4" orderby="date" order="DESC"]'); ?>
    </div>
  </section>
  <section class="section section-alt">
    <div class="container">
      <div class="section-head"><h2>Best Sellers</h2><p>High-demand items for repeat orders, wholesale projects and custom bag manufacturing.</p></div>
      <?php echo do_shortcode('[best_selling_products limit="8" columns="4"]'); ?>
    </div>
  </section>
  <section class="section">
    <div class="container split-grid">
      <div class="service-card">
        <p class="kicker">Custom Solutions</p>
        <h2>Logo hardware, plating colors and OEM/ODM development</h2>
        <p>Send drawings, finish samples, target price and estimated quantity. We help prepare mold options, plating references, packaging and reorder standards.</p>
        <ul class="check-list"><li>Logo engraving and embossing</li><li>Color plating and finish matching</li><li>Material and size adjustment</li><li>Custom mold development</li></ul>
      </div>
      <div class="service-card image"></div>
    </div>
  </section>
  <section class="newsletter">
    <div class="container">
      <div><h2>Get material updates and wholesale support</h2><p>Create an account or subscribe to receive new product information, sample support and quotation follow-up.</p></div>
      <form action="<?php echo esc_url(home_url('/contact/')); ?>" method="get"><input type="email" name="email" placeholder="Your email address" required /><button>Subscribe</button></form>
    </div>
  </section>
</main>
<?php get_footer(); ?>
